from .bsa_transition_probe_compat import install_bsa_transition_probe_compat
from .bsa_transition_probe_manual import install_bsa_transition_probe_manual_only
from .comfy_compiler_compat import install_comfy_compiler_compat
from .config import AGGRESSIVE_PRESET, CONSERVATIVE_PRESET, SpectrumH3Config
from .core_bsa_forecast_recovery import install_core_bsa_forecast_recovery
from .core_bsa_loader_compat import install_core_bsa_loader_compat
from .er_sde_offline_replay_safety import install_er_sde_offline_replay_safety
from .er_sde_policy import install_er_sde_tail_policy
from .external_patch_compat import install_external_patch_compat
from .external_patch_hardening import install_external_patch_hardening
from .external_patch_visual_reference import install_visual_reference_patch_compat
from .forecast import HistoryWeightForecaster
from .generic_correction import install_generic_residual_correction
from .minimax_h3 import locate_minimax_h3_inner, require_native_minimax_h3
from .nodes import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS
from .postrun_safety import install_postrun_safety
from .refinement_compat import install_refinement_compat
from .replay_calibration import install_replay_calibration
from .replay_calibration_provenance import install_replay_calibration_provenance
from .replay_calibration_validation import install_replay_calibration_validation
from .replay_component_shadow import install_replay_component_decomposition
from .replay_generic_correction_gate import install_replay_generic_correction_gate
from .replay_shadow_composition import install_replay_shadow_composition
from .replay_spectral_alpha_shadow import install_replay_spectral_alpha_shadow
from .replay_spectral_mixture_shadow import install_replay_spectral_mixture_shadow
from .replay_trust_shadow import install_replay_native_trust_shadow
from .runtime import SpectrumH3Runtime
from .trust_probe import install_forecast_trust_probe

install_core_bsa_loader_compat()
install_bsa_transition_probe_compat()
install_bsa_transition_probe_manual_only()
install_generic_residual_correction()
install_postrun_safety()
install_forecast_trust_probe()
install_replay_native_trust_shadow()
install_replay_component_decomposition()
install_replay_shadow_composition()
install_replay_spectral_mixture_shadow()
install_replay_spectral_alpha_shadow()
install_replay_generic_correction_gate()
install_replay_calibration()
install_replay_calibration_validation()
install_replay_calibration_provenance()
install_er_sde_tail_policy()
install_refinement_compat()
install_external_patch_compat()
install_visual_reference_patch_compat()
install_external_patch_hardening()
install_er_sde_offline_replay_safety()
# The BSA recovery wrapper must see the final scheduler/rollback decision made by
# the compatibility layers above. Compiler compatibility remains outermost.
install_core_bsa_forecast_recovery()
# Compiler compatibility must be outermost: it owns the thread-local lifetime
# from Spectrum step entry through every already-installed finalize/end wrapper.
install_comfy_compiler_compat()

# External compatibility wraps the already-installed safe end-run hook. Preserve
# the inner implementation's identity and expose the effective outermost hook
# separately so teardown invariants can verify both layers of the chain.
from . import postrun_safety as _postrun_safety

_postrun_safety.EFFECTIVE_END_RUN_HOOK = SpectrumH3Runtime.end_run

__all__ = [
    "AGGRESSIVE_PRESET",
    "CONSERVATIVE_PRESET",
    "NODE_CLASS_MAPPINGS",
    "NODE_DISPLAY_NAME_MAPPINGS",
    "HistoryWeightForecaster",
    "SpectrumH3Config",
    "SpectrumH3Runtime",
    "locate_minimax_h3_inner",
    "require_native_minimax_h3",
]
